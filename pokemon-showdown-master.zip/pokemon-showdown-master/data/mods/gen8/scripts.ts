export const Scripts: ModdedBattleScriptsData = {
	gen: 8,
};
