export const Moves: {[k: string]: ModdedMoveData} = {
	dragonascent: {
		inherit: true,
		isNonstandard: "Future",
	},
	hyperspacefury: {
		inherit: true,
		isNonstandard: "Future",
	},
	originpulse: {
		inherit: true,
		isNonstandard: "Future",
	},
	precipiceblades: {
		inherit: true,
		isNonstandard: "Future",
	},
};
